package main.java.codeExecution;

public interface RealTimeOperation{
    void run(InputMessage message);
}
