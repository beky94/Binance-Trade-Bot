package main.java.strategies.MACrosses.Long;

import data.DataHolder;
import positions.SellingInstructions;
import strategies.ExitStrategy;

public class MACrossesLongExitStrategy1 implements ExitStrategy {
    @Override
    public SellingInstructions run(DataHolder realTimeData) {
        return null;
    }
}
