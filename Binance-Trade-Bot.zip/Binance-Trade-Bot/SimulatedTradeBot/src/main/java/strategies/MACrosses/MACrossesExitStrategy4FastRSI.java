package main.java.strategies.MACrosses;

public class MACrossesExitStrategy4FastRSI {
}
