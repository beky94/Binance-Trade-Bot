package strategies.rsiDivergence;

import data.DataHolder;
import positions.SellingInstructions;
import strategies.ExitStrategy;

public class BaseRsiDivergenceExitStrategy implements ExitStrategy {
    protected boolean positionsClosed = false;

    @Override
    public SellingInstructions run(DataHolder realTimeData) {
        return null;
    }
}
