package strategies.rsiDivergence;

import TradingTools.Trailers.SkippingExitTrailer;
import com.binance.client.SyncRequestClient;
import com.binance.client.model.enums.*;
import com.binance.client.model.trade.Order;
import data.AccountBalance;
import data.Config;
import data.DataHolder;
import positions.PositionHandler;
import singletonHelpers.BinanceInfo;
import singletonHelpers.RequestClient;
import singletonHelpers.TelegramMessenger;
import strategies.EntryStrategy;
import strategies.ExitStrategy;
import utils.Utils;

import java.util.ArrayList;
import java.util.Date;
public class RsiDivergeceEntryStrategy implements EntryStrategy {
    private PositionHandler positionHandler;
    private AccountBalance accountBalance;
    private double requestedBuyingAmount = RsiDivergeceConstance.BUYING_AMOUNT;
    private int leverage = RsiDivergeceConstance.LEVRAGE;
    private boolean firstTrade = true;
    private boolean freeToTrade = true;
    private double[] takeProfitPercentages = RsiDivergeceConstance.TP_PRECENTAGES;
    private double[] takeProfitQty = RsiDivergeceConstance.TP_PRECENTAGES;
    ArrayList<ExitStrategy> exitStrategies = new ArrayList<>();

    public RsiDivergeceEntryStrategy(){
        accountBalance = AccountBalance.getAccountBalance();
        System.out.println("Rsi Divergence");
    }

    @Override
    public PositionHandler run(DataHolder realTimeData, String symbol) {
        System.out.println(realTimeData.getFastSmaValue(realTimeData.getSeconderyLastCloseIndex()));
        System.out.println(realTimeData.getSeconderyClosePriceValueAtIndex(realTimeData.getSeconderyLastIndex()));
//        if (firstTrade){
//            if(devCrossedUp(realTimeData)){
//                firstTrade = false;
//                freeToTrade = false;
//                return buyAndCreatePositionHandler(realTimeData,PositionSide.LONG, symbol);
//            } else if(devCrossedDown(realTimeData)){
//                firstTrade = false;
//                freeToTrade = false;
//                return buyAndCreatePositionHandler(realTimeData,PositionSide.SHORT, symbol);
//            }
//        }
//        else if (freeToTrade){
//            double dev = realTimeData.getRsiDivergenceAtIndex(realTimeData.getLastCloseIndex());
//            double currentDev = realTimeData.getRsiDivergenceAtIndex(realTimeData.getLastIndex());
//            freeToTrade = false;
//            if(dev > 0.1 && currentDev > 0.0){
//                freeToTrade = false;
//                return buyAndCreatePositionHandler(realTimeData,PositionSide.LONG, symbol);
//            }else if(dev < 0.1 && currentDev < 0.0){
//                freeToTrade = false;
//                return buyAndCreatePositionHandler(realTimeData,PositionSide.SHORT, symbol);
//                }
//        }
//        for(ExitStrategy baseRsiDivergenceExitStrategy:exitStrategies){
//            if (baseRsiDivergenceExitStrategy.positionIsClosed){
//                positionClosed();
//            }
//        }

        return null;
    }

    private boolean devCrossedDown(DataHolder realTimeData) {
        int index = realTimeData.getLastCloseIndex();
        double currDev = realTimeData.getRsiDivergenceAtIndex(index);
        double prevDev = realTimeData.getRsiDivergenceAtIndex(index - 1);
        return prevDev > 0 && currDev <= 0;
    }

    private boolean devCrossedUp(DataHolder realTimeData) {
        int index = realTimeData.getLastCloseIndex();
        double currDev = realTimeData.getRsiDivergenceAtIndex(index);
        double prevDev = realTimeData.getRsiDivergenceAtIndex(index - 1);
        return prevDev < 0 && currDev >= 0;
    }


    private PositionHandler buyAndCreatePositionHandler(DataHolder realTimeData, PositionSide positionSide, String symbol){
        ArrayList<ExitStrategy> exitStrategies1 = exitStrategies;
        setLeverage(symbol);
        TelegramMessenger.sendToTelegram("Entering new position " + new Date(System.currentTimeMillis()));
        int startIndex = realTimeData.getLastIndex();
        SkippingExitTrailer skippingExitTrailer = new SkippingExitTrailer(RsiDivergeceConstance.TRAILING_PRECENTAGE, positionSide);
        exitStrategies.add(new rsiDivergenceExitStrategy1(positionSide, skippingExitTrailer, startIndex));
        double currentPrice = realTimeData.getCurrentPrice();
        SyncRequestClient syncRequestClient = RequestClient.getRequestClient().getSyncRequestClient();
        syncRequestClient.changeInitialLeverage(symbol, leverage);
        String buyingQty = Utils.getBuyingQtyAsString(currentPrice, symbol, leverage, requestedBuyingAmount);
        if (positionSide == PositionSide.LONG) {
            try {
                Order buyOrder = syncRequestClient.postOrder(symbol, OrderSide.BUY, null, OrderType.MARKET, null,
                        buyingQty, null, null, null, null, null, null, null, WorkingType.MARK_PRICE, "TRUE", NewOrderRespType.RESULT);
                TelegramMessenger.sendToTelegram("bought long:  " + "Side: " + buyOrder.getSide() + " , Qty: " + buyOrder.getCumQty() +
                        " , Average Price: " + buyOrder.getAvgPrice() + " ,                   Time: " + new Date(System.currentTimeMillis()));
                positionHandler = new PositionHandler(buyOrder, (ArrayList<ExitStrategy>)exitStrategies, RsiDivergeceConstance.STOP_LOSS_PERCENTAGE, positionSide);
                return positionHandler;
            } catch (Exception e) {
                TelegramMessenger.sendToTelegram("Exception was thrown" + new Date(System.currentTimeMillis()));
                e.printStackTrace();
            }
        }
        else {
            try {
                Order buyOrder = syncRequestClient.postOrder(symbol, OrderSide.SELL, null, OrderType.MARKET, null,
                        buyingQty, null, null, null, null, null, null, null, WorkingType.MARK_PRICE,"TRUE" , NewOrderRespType.RESULT);
                TelegramMessenger.sendToTelegram("bought short:  " + "Side: " + buyOrder.getSide() + " , Qty: " + buyOrder.getCumQty() +
                        " , Average Price: " + buyOrder.getAvgPrice() + " ,                   Time: " + new Date(System.currentTimeMillis()));
                positionHandler = new PositionHandler(buyOrder, exitStrategies, RsiDivergeceConstance.STOP_LOSS_PERCENTAGE, positionSide);
                return positionHandler;
            } catch (Exception e) {
                TelegramMessenger.sendToTelegram("Exception was thrown" + new Date(System.currentTimeMillis()));
                e.printStackTrace();
            }
        }
        int i = 0;
        for(double takeProfitPercentage: takeProfitPercentages) {
            String tpPrice = BinanceInfo.formatPrice(calculateTakeProfit(currentPrice, positionSide, takeProfitPercentage), symbol);
            String sellingQty = Utils.getBuyingQtyAsString(currentPrice, symbol, leverage, calculateTakeProfitQty(requestedBuyingAmount, takeProfitQty[i++]));
            switch (positionSide) {
                case LONG:
                    try {
                        syncRequestClient.postOrder(symbol, OrderSide.SELL, PositionSide.BOTH, OrderType.TAKE_PROFIT_MARKET, TimeInForce.GTC,
                                sellingQty, null, "true", null, tpPrice, null,
                                null, null, WorkingType.MARK_PRICE, "true", NewOrderRespType.RESULT);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;

                case SHORT:
                    try {
                        syncRequestClient.postOrder(symbol, OrderSide.BUY, PositionSide.BOTH, OrderType.STOP_MARKET, TimeInForce.GTC,
                                sellingQty, null, "true", null, tpPrice, null,
                                null, null, WorkingType.MARK_PRICE, "true", NewOrderRespType.RESULT);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;

                default:
                    break;
            }
        }
        return null;
    }


    public void postTakeProfit(double qty, double averagePrice, PositionSide positionSide,String symbol, double tpPricePrecentag){
        SyncRequestClient syncRequestClient = RequestClient.getRequestClient().getSyncRequestClient();
        String sellingQty = Utils.fixQuantity(BinanceInfo.formatQty(qty, symbol));
        String tPPrice;
        switch (positionSide) {

            case LONG:
                try {
                    tPPrice = BinanceInfo.formatPrice(averagePrice + ((averagePrice / 100) * tpPricePrecentag), symbol);
                    syncRequestClient.postOrder(symbol, OrderSide.SELL, PositionSide.BOTH, OrderType.TAKE_PROFIT_MARKET, TimeInForce.GTC,
                            sellingQty, null, "true", null, tPPrice, null,
                            null, null, WorkingType.MARK_PRICE, "true", NewOrderRespType.RESULT);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            case SHORT:
                tPPrice = BinanceInfo.formatPrice(averagePrice - ((averagePrice / 100) * tpPricePrecentag), symbol);
                try {
                    syncRequestClient.postOrder(symbol, OrderSide.BUY, PositionSide.BOTH, OrderType.STOP_MARKET, TimeInForce.GTC,
                            sellingQty, null, "true", null, tPPrice, null,
                            null, null, WorkingType.MARK_PRICE, "true", NewOrderRespType.RESULT);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            default:
                break;
        }
    }


    private double calculateTakeProfitQty(double requestedBuyingAmount,double sellingPrecenteage) {
        return requestedBuyingAmount / 100 * sellingPrecenteage;

    }

    private double calculateTakeProfit(double currentPrice, PositionSide positionSide,double takeProfitPercentage) {
        switch (positionSide){

            case SHORT:
                return currentPrice - currentPrice * (takeProfitPercentage / 100);
            case LONG:
                return currentPrice + currentPrice * (takeProfitPercentage / 100);
        }
        return currentPrice;//never
    }

    private void updateBuyingAmount(String symbol) {
        String baseSymbol = Config.BASE_COIN;
        double balance = accountBalance.getCoinBalance(baseSymbol).doubleValue();
        requestedBuyingAmount = (balance * RsiDivergeceConstance.AVAILABLE_BALANCE_PERCENTAGE) / 100;

    }


    private void setLeverage(String symbol){
        switch (symbol){

            case "bnbusdt":
                leverage = 75;
                break;
            case "ethusdt":
                leverage = 100;
                break;
            case "btcusdt":
                leverage = 100;
                break;
            case "dogeusdt" :
                leverage = 50;
                break;
        }
    }

    @Override
    public void setLeverage(int leverage) {

    }

    @Override
    public void setRequestedBuyingAmount(double requestedBuyingAmount) {

    }

    @Override
    public void positionClosed() {
        freeToTrade = true;
    }
}
