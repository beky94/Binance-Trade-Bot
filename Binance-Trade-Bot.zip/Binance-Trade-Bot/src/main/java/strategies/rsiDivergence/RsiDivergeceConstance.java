package strategies.rsiDivergence;

public class RsiDivergeceConstance {
    public static final int FAST = 50;
    public static final int SLOW = 140;

    public static final int LEVRAGE = 100;
    public static final double BUYING_AMOUNT = 5;
    public static final double STOP_LOSS_PERCENTAGE = 1;
    public static final double AVAILABLE_BALANCE_PERCENTAGE = 10;
    public static final double[] TP_PRECENTAGES = {1,2,3};
    public static final double TRAILING_PRECENTAGE = 0.05;
    private static final double[] TP_QTY = {20,20,30};
}
