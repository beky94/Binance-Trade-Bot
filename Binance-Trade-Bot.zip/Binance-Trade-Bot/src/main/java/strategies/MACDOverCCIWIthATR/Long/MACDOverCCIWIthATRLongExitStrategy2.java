package strategies.MACDOverCCIWIthATR.Long;

import data.DataHolder;
import positions.SellingInstructions;
import strategies.ExitStrategy;

public class MACDOverCCIWIthATRLongExitStrategy2 implements ExitStrategy {

    @Override
    public SellingInstructions run(DataHolder realTimeData) {
        return null;
    }

}
