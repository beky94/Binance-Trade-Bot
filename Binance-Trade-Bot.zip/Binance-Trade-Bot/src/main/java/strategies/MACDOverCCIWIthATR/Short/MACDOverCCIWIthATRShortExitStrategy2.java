package strategies.MACDOverCCIWIthATR.Short;

import data.DataHolder;
import positions.SellingInstructions;
import strategies.ExitStrategy;

public class MACDOverCCIWIthATRShortExitStrategy2 implements ExitStrategy {

    @Override
    public SellingInstructions run(DataHolder realTimeData) {
        return null;
    }
    //    if bb width is expanding & candel indicates long
}
