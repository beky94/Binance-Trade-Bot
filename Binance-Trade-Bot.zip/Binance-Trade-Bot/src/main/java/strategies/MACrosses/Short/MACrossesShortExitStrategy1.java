package strategies.MACrosses.Short;

import data.DataHolder;
import positions.SellingInstructions;
import strategies.ExitStrategy;

public class MACrossesShortExitStrategy1 implements ExitStrategy  {

    @Override
    public SellingInstructions run(DataHolder realTimeData) {
        return null;
    }
}
