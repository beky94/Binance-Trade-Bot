package strategies.MACrosses.Long;

import data.DataHolder;
import positions.SellingInstructions;
import strategies.ExitStrategy;

public class MACroosesLongExitStrategy2 implements ExitStrategy {

    @Override
    public SellingInstructions run(DataHolder realTimeData) {
        return null;
    }
}
