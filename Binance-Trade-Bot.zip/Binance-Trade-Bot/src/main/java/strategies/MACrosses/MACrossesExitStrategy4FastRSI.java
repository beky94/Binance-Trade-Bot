package strategies.MACrosses;

public class MACrossesExitStrategy4FastRSI {
}
