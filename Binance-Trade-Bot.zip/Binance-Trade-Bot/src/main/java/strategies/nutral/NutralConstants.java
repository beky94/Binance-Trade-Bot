package strategies.nutral;

public class NutralConstants {
    public static final double TP_STEP = 0.07;
    public static final double SL_STEP = 0.03;
    public static final double QTY = 0.01;
}
