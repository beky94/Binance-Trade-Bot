package strategies;

public enum PositionInStrategy {
	POSITION_ONE,
	POSITION_TWO,
	POSITION_THREE
}
