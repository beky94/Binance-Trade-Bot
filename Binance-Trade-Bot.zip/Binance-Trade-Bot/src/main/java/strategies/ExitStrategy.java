package strategies;

import data.DataHolder;
import positions.SellingInstructions;

public interface ExitStrategy {
    public boolean positionIsClosed = true;
    SellingInstructions run(DataHolder realTimeData);

    public default boolean getPositionIsClosed(){return positionIsClosed;}
}
