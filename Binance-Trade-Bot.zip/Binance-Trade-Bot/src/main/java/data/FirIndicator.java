package data;

import org.ta4j.core.Indicator;
import org.ta4j.core.indicators.CachedIndicator;
import org.ta4j.core.num.Num;

public class FirIndicator extends CachedIndicator<Num> {
    private final Indicator<Num> indicator;


    public FirIndicator(Indicator<Num> indicator) {
        super(indicator);
        this.indicator = indicator;
    }

    @Override
    protected Num calculate(int i) {
        Num val =  (Num)indicator.getValue(i);
        Num val1 = (Num)indicator.getValue(i - 1);
        Num val2 = (Num)indicator.getValue(i - 2);
        Num val3 = (Num)indicator.getValue(i -3);
        return val.multipliedBy(numOf(4)).plus(val1.multipliedBy(numOf(3)).plus(val2.multipliedBy(numOf(2)).plus(val3))).dividedBy(numOf(10));
    }
}
