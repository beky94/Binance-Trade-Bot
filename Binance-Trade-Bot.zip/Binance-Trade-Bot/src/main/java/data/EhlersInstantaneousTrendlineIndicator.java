package data;

import org.ta4j.core.Indicator;
import org.ta4j.core.indicators.CachedIndicator;
import org.ta4j.core.indicators.helpers.ClosePriceIndicator;
import org.ta4j.core.indicators.helpers.FixedIndicator;
import org.ta4j.core.num.Num;

import java.util.ArrayList;
import java.util.List;

public class EhlersInstantaneousTrendlineIndicator extends CachedIndicator<Num> {

    double pi = 2 * Math.asin(1);
    double piriod = 0.0;
    private ClosePriceIndicator closePriceIndicator;
    private  FixedIndicator<Num> mesaPeriod;
    private  FirIndicator fir;
    private boolean firstTime = true;
    private FixedIndicator<Num> detrender;

    int index;

//    public EhlersInstantaneousTrendlineIndicator(BarSeries series, int index) {
//        super(series);
//        this.index = index;
//        closePriceIndicator = new ClosePriceIndicator(series);
//        calculateHilbertTransform();
//    }

    public EhlersInstantaneousTrendlineIndicator(Indicator<Num> indicator, int index) {
        super(indicator);
        this.index = index;
        fir = new FirIndicator(indicator);
        final List<Num> values = new ArrayList<Num>();
//        for(int i = 0; i < 3 ; i++){
//            values.add(computeComponent(fir,))
//        }
        List<Num> mesaPeriodVals = new ArrayList<Num>();
        mesaPeriodVals.add(numOf(0.0));
        mesaPeriod = new FixedIndicator ((indicator.getBarSeries()), mesaPeriodVals);
        detrender = computeComponent(fir, numOf(0.54));
    }


    private Num calculateHilbertTransform(Indicator<Num> indicator){
        Num val = indicator.getValue(index);
        Num val2 =indicator.getValue(index - 2);
        Num val4 =indicator.getValue(index - 4);
        Num val6 =indicator.getValue(index - 6);
        return  val.multipliedBy(numOf(0.962)).plus(val2.multipliedBy(numOf(0.5769)).minus(val4.multipliedBy(numOf(0.5769))).minus(val6.multipliedBy(numOf(0.5769))));

    }

    private FixedIndicator<Num> computeComponent(Indicator<Num> indicator, Num periodMult ){
        int i = indicator.getBarSeries().getBeginIndex();
        List<Num> vals = new ArrayList<Num>();
        while(i++ <= indicator.getBarSeries().getEndIndex()){
            vals.add(calculateHilbertTransform(indicator).multipliedBy(periodMult));
        }
        return (FixedIndicator<Num>) new FixedIndicator(indicator.getBarSeries(), vals);
    }

    private  Num computePart(FixedIndicator<Num> fixedIndicator){
        int i = fixedIndicator.getBarSeries().getEndIndex();
        Num currVal = fixedIndicator.getValue(i);
        Num prevVal = fixedIndicator.getValue(i - 1);
        return  currVal.multipliedBy(numOf(0.2)).plus(prevVal.multipliedBy(numOf(0.8)));
    }

    @Override
    protected Num calculate(int i) {
        calculateValue(closePriceIndicator, index);
        Num pi = numOf(2 * Math.asin(1));
        Num mesaPeriodMult = mesaPeriod.getValue(index).multipliedBy(numOf(0.075).plus(numOf(0.54)));

        return null;
    }
    protected Num calculateValue(ClosePriceIndicator closePriceIndicator, int index){

        Num pi = numOf(2 * Math.asin(1));
        Num mesaPeriodMult = mesaPeriod.getValue(index).multipliedBy(numOf(0.075).plus(numOf(0.54)));

        detrender = (FixedIndicator<Num>) computeComponent(fir, mesaPeriodMult);
        // Compute InPhase and Quadrature components
        FixedIndicator<Num> i1 = new FixedIndicator<Num>(detrender.getBarSeries(),getValue(index - 3));
        FixedIndicator<Num> q1 = computeComponent(detrender, mesaPeriodMult);
        FixedIndicator<Num> ji = computeComponent(i1, mesaPeriodMult);;
        FixedIndicator<Num> jq = computeComponent(q1, mesaPeriodMult);;

        // Phasor addition for 3 bar averaging
        FixedIndicator<Num> i2 = new FixedIndicator<Num>(detrender.getBarSeries(), i1.getValue(index).minus(jq.getValue(index)));
        FixedIndicator<Num> q2 = new FixedIndicator<Num>(detrender.getBarSeries(), q1.getValue(index).plus(ji.getValue(index)));

        // Smooth the I and Q components before applying the discriminator
        Num reVal = i2.getValue(index).multipliedBy(i2.getValue(index - 1)).plus(q2.getValue(index).multipliedBy(q2.getValue(index - 1)));
        Num imVal = q2.getValue(index).multipliedBy(q2.getValue(index - 1)).minus(i2.getValue(index).multipliedBy(i2.getValue(index - 1)));

        FixedIndicator<Num> re = new FixedIndicator<Num>(detrender.getBarSeries(), numOf(0.0), reVal);
        FixedIndicator<Num> im = new FixedIndicator<Num>(detrender.getBarSeries(), numOf(0.0), imVal);
        re.addValue(computePart(re));
        im.addValue(computePart(im));







    }

}
