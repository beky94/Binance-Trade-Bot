package codeExecution;

public interface RealTimeOperation{
    void run(InputMessage message);
}
